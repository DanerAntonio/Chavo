import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);
	        BilleteraElectronica billetera = new BilleteraElectronica();

	        int opcion;
	        double cantidad;

	        do {
	            System.out.println("\n--- Menú ---");
	            System.out.println("1. Depositar dinero");
	            System.out.println("2. Retirar dinero");
	            System.out.println("3. Salir");
	            System.out.print("Seleccione una opción: ");
	            opcion = scanner.nextInt();

	            switch (opcion) {
	                case 1:
	                    System.out.print("Ingrese la cantidad a depositar: $");
	                    cantidad = scanner.nextDouble();
	                    billetera.depositar(cantidad);
	                    break;
	                case 2:
	                    System.out.print("Ingrese la cantidad a retirar: $");
	                    cantidad = scanner.nextDouble();
	                    billetera.retirar(cantidad);
	                    break;
	                case 3:
	                    System.out.println("Saliendo del programa...");
	                    break;
	                default:
	                    System.out.println("Opción inválida. Por favor, seleccione una opción válida.");
	            }
	        } while (opcion != 3);

	        scanner.close();
	    }
	
	}


