import java.util.Scanner;
public class BilleteraElectronica {
	double capital;

    public BilleteraElectronica() {
        this.capital = 0;
    }

    public void depositar(double cantidad) {
        capital += cantidad;
        System.out.println("Se ha depositado $" + cantidad + ". Capital actual: $" + capital);
    }

    public void retirar(double cantidad) {
        if (cantidad > capital) {
            System.out.println("No se puede retirar $" + cantidad + ". Fondos insuficientes. Capital actual: $" + capital);
        } else {
            capital -= cantidad;
            System.out.println("Se ha retirado $" + cantidad + ". Capital actual: $" + capital);
        }
    }

    public double getCapital() {
        return capital;
    }
}

