
public class Mascota {
	  	String nombre;
	     String especie;
	     int edad;
	     String estado;

	    public Mascota(String nombre, String especie, int edad, String estado) {
	        this.nombre = nombre;
	        this.especie = especie;
	        this.edad = edad;
	        this.estado = estado;
	    }

	    public void registrar() {
	        System.out.println("Registrando mascota: " + getNombre());
	    }

	    public void modificarEdad(int nuevaEdad) {
	        setEdad(nuevaEdad);
	        System.out.println("La edad de " + getNombre() + " ha sido modificada a " + getEdad() + ".");
	    }

	    public void consultar() {
	        System.out.println("Nombre: " + getNombre() + ", Especie: " + getEspecie() + ", Edad: " + getEdad() + ", Estado: " + getEstado());
	    }

	    public void cambiarEstado(String nuevoEstado) {
	        setEstado(nuevoEstado);
	        System.out.println("El estado de " + getNombre() + " ha sido cambiado a " + getEstado() + ".");
	    }

	    // Getters y Setters
	    public String getNombre() {
	        return nombre;
	    }

	    public void setNombre(String nombre) {
	        this.nombre = nombre;
	    }

	    public String getEspecie() {
	        return especie;
	    }

	    public void setEspecie(String especie) {
	        this.especie = especie;
	    }

	    public int getEdad() {
	        return edad;
	    }

	    public void setEdad(int edad) {
	        this.edad = edad;
	    }

	    public String getEstado() {
	        return estado;
	    }

	    public void setEstado(String estado) {
	        this.estado = estado;
	    }
	}


