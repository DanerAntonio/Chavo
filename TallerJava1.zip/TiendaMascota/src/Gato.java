
public class Gato extends Mascota {
	
	    String color;

	    public Gato(String nombre, int edad, String estado, String color) {
	        super(nombre, "Gato", edad, estado);
	        this.color = color;
	    }

	    @Override
	    public void registrar() {
	        super.registrar();
	        System.out.println("Se ha registrado un gato de color " + color + ".");
	    }

	    @Override
	    public void consultar() {
	        super.consultar();
	        System.out.println("Color: " + color);
	    }
	}


