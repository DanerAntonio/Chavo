
public class Perro extends Mascota {
	
	    String raza;

	    public Perro(String nombre, int edad, String estado, String raza) {
	        super(nombre, "Perro", edad, estado);
	        this.raza = raza;
	    }

	    @Override
	    public void registrar() {
	        super.registrar();
	        System.out.println("Se ha registrado un perro de raza " + raza + ".");
	    }

	    @Override
	    public void consultar() {
	        super.consultar();
	        System.out.println("Raza: " + raza);
	    }
	}


