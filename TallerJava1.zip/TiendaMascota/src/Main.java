
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Perro perro1 = new Perro("Buddy", 5, "Saludable", "Labrador");
	        Gato gato1 = new Gato("Whiskers", 3, "Enfermo", "Blanco");

	        // Verificación de la creación de los objetos
	        perro1.registrar();
	        gato1.registrar();

	        // Consulta de información
	        perro1.consultar();
	        gato1.consultar();

	        // Modificación de edad
	        perro1.modificarEdad(6);

	        // Cambio de estado
	        gato1.cambiarEstado("Saludable");
	    }
	
	}


