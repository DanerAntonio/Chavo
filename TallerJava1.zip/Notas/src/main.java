
import java.util.Scanner;



public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		System.out.println("****Notas universidad****");
		
		   Notas notasEstudiante1 = new Notas("", "", 3, 3);
	        Notas notasEstudiante2 = new Notas("", "", 3, 3);

	      
	        System.out.println("Estudiante 1:");
	        System.out.println(notasEstudiante1);
	        System.out.println();

	        System.out.println("Estudiante 2:");
	        System.out.println(notasEstudiante2);
	    }
	}


 