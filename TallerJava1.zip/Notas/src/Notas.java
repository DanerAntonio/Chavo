
public class Notas {
	


	//crea una clase llamada notas  con los atributos , 
	//documento,asignatura,nota60,nota40 metodos: set,get, 
	//clacular nota final , override . la nota final correspomde 
	//a la suma de la multiplicacion de 60 por 0.6 y 40 por 0.40 
	//crea dos objetos donde se imprima el objeto creado,la nota 
	//final o si se aprobo o no. se aprueba con una nota final superior o igual a 3.0 en java
		
	
//definir los atributos
	String documento;
	String asignatura;
	int nota60;
	int nota40;
	
	

	// definir constructor de la clase
	Notas(String documentos, String asignatura, int nota60, int nota40) {
		this.documento = documento;
		this.asignatura = asignatura;
		this.nota60 = nota60;
		this.nota40 = nota40;
	}
		// asignar metdo set
		public void setDocumento(String documento) {
			this.documento = documento;
		}

		public void setAsignatura(String asignatura) {
			this.asignatura = asignatura;
		}

		public void setNota60(int nota60) {
			this.nota60 = nota60;
		}

		public void setNota40(int nota40) {
			this.nota40 = nota40;
		}
		
		// definir el metodo get
		public String getDocumento() {
			return this.documento;
		}

		public String getAsignatura() {
			return this.asignatura;
		}

		public double getNota60() {
			return this.nota60;
		}

		public double getNota40() {
			return this.nota40;
		}
		
		// agregar metodo

		  public double calcularNotaFinal() {
		        return (this.nota60 * 0.6) + (this.nota40 * 0.4);
		    }

		    // Método para determinar si se aprobó o no
		    public boolean aprobar() {
		        return calcularNotaFinal() >= 3.0;
		    }
		    @Override
		    public String toString() {
		        return "Estudiante: " + this.documento + ", Asignatura: " + this.asignatura + ", Nota Final: "
		                + calcularNotaFinal() + ", ¿Aprobado?: " + (aprobar() ? "Sí" : "No");
		    }

	
		}


	
	

