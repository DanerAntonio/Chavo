
public abstract class Figura {
	
	    abstract double calcularArea();
	    abstract double calcularPerimetro();
	}


