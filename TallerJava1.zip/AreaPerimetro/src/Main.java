
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Circulo circulo = new Circulo(5);
	        Cuadrado cuadrado = new Cuadrado(4);
	        Rectangulo rectangulo = new Rectangulo(3, 6);

	        // Calcular y mostrar área y perímetro
	        System.out.println("Círculo:");
	        System.out.println("Área: " + circulo.calcularArea());
	        System.out.println("Perímetro: " + circulo.calcularPerimetro());

	        System.out.println("\nCuadrado:");
	        System.out.println("Área: " + cuadrado.calcularArea());
	        System.out.println("Perímetro: " + cuadrado.calcularPerimetro());

	        System.out.println("\nRectángulo:");
	        System.out.println("Área: " + rectangulo.calcularArea());
	        System.out.println("Perímetro: " + rectangulo.calcularPerimetro());
	    }
	
	}


