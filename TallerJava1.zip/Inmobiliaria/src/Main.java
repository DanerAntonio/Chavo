
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		
		   
		        // Ejemplo de creación de objetos de cada clase
		        Apartamento apartamento = new Apartamento("A001", "Bogotá", "Cra 10 #20-30", 80, 2000000, 1500000, 3);
		        Casa casa = new Casa("C001", "Medellín", "Calle 50 #80-90", 150, 1800000, 2000000, 2);
		        Finca finca = new Finca("F001", "Cali", "Vereda El Carmen", 5000, 1000000, 500000, "Agrícola");

		        // Ejemplo de uso de métodos
		        System.out.println("Valor de venta del apartamento: $" + apartamento.calcularValorVenta());
		        System.out.println("Valor de venta de la casa: $" + casa.calcularValorVenta());
		        System.out.println("Valor de venta de la finca: $" + finca.calcularValorVenta());
		    }
		   }

	   

	


