// Clase Apartamento (subclase de Inmueble)
class Apartamento extends Inmueble {
    private int numeroHabitaciones;

    // Constructor
    public Apartamento(String codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual, int numeroHabitaciones) {
        super(codigo, ciudad, direccion, area, valormetrocuadrado, valorarriendomensual);
        this.numeroHabitaciones = numeroHabitaciones;
    }

    // Método para calcular el valor de venta del apartamento
    @Override
    public double calcularValorVenta() {
        return getArea() * getValormetrocuadrado();
    }
}


