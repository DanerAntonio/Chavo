
class Finca extends Inmueble {
    private String tipoTerreno;

    // Constructor
    public Finca(String codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual, String tipoTerreno) {
        super(codigo, ciudad, direccion, area, valormetrocuadrado, valorarriendomensual);
        this.tipoTerreno = tipoTerreno;
    }

    // Método para calcular el valor de venta de la finca
    @Override
    public double calcularValorVenta() {
        return getArea() * getValormetrocuadrado();
    }
}

