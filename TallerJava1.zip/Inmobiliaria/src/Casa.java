class Casa extends Inmueble {
    private int numeroPisos;

    // Constructor
    public Casa(String codigo, String ciudad, String direccion, double area, double valormetrocuadrado, double valorarriendomensual, int numeroPisos) {
        super(codigo, ciudad, direccion, area, valormetrocuadrado, valorarriendomensual);
        this.numeroPisos = numeroPisos;
    }

    // Método para calcular el valor de venta de la casa
    @Override
    public double calcularValorVenta() {
        return getArea() * getValormetrocuadrado();
    }
}