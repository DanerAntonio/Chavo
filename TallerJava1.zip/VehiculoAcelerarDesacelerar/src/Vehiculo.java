
public class Vehiculo {
	 private int velocidad;

	    public Vehiculo() {
	        this.velocidad = 0;
	    }

	    public void acelerar(int incremento) {
	        velocidad += incremento;
	        System.out.println("El vehículo ha acelerado. Velocidad actual: " + velocidad);
	    }

	    public void desacelerar(int decremento) {
	        velocidad -= decremento;
	        if (velocidad < 0) {
	            velocidad = 0;
	        }
	        System.out.println("El vehículo ha desacelerado. Velocidad actual: " + velocidad);
	    }

	    public int getVelocidad() {
	        return velocidad;
	    }
	}


