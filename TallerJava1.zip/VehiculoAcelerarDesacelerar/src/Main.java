
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vehiculo vehiculo = new Vehiculo();

        // Acelerar el vehículo en 20 km/h
        vehiculo.acelerar(20);

        // Desacelerar el vehículo en 10 km/h
        vehiculo.desacelerar(10);
    }

	}


