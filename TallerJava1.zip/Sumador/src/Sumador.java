

	public class Sumador {
	    // Método sumar para enteros
	    public int sumar(int a, int b, int c) {
	        return a + b + c;
	    }

	    // Método sumar para flotantes
	    public float sumar(float a, float b, float c) {
	        return a + b + c;
	    }

	    // Método sumar para doubles
	    public double sumar(double a, double b, double c) {
	        return a + b + c;
	    }

	    public static void main(String[] args) {
	        Sumador sumador = new Sumador();

	        // Sumar enteros
	        int sumaEnteros = sumador.sumar(5, 10, 15);
	        System.out.println("Suma de enteros: " + sumaEnteros);

	        // Sumar flotantes
	        float sumaFlotantes = sumador.sumar(2.5f, 3.5f, 4.5f);
	        System.out.println("Suma de flotantes: " + sumaFlotantes);

	        // Sumar doubles
	        double sumaDoubles = sumador.sumar(2.5, 3.5, 4.5);
	        System.out.println("Suma de doubles: " + sumaDoubles);
	    }
	}


