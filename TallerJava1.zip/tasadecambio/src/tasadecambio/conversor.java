package tasadecambio;

public class conversor {
//crear una clase llamada conversor que permita convertir pesos a 
//dolares y euros se debe implementar los metodos get set , override,convertirDolares,convertirEuros, 
//ingresa por teclado la cantidad de pesos a convertir e imprime los valores de la conversion
	
	//definir atributos 
	double tasaDolar;
	double tasaEuro;
	double cantidadPesos;

	// definimos constructor
	conversor(double tasaDolar, double tasaEuro, double cantidadPesos) {
		this.tasaDolar = tasaDolar;
		this.tasaEuro = tasaEuro;
		this.cantidadPesos = cantidadPesos;
	}

	// definir metodo set
	public void setTasaDolar(double tasaDolar) {
		this.tasaDolar = tasaDolar;
	}

	public void setTasaEuro(double tasaEuro) {
		this.tasaEuro = tasaEuro;
	}
	
	public void setCantidadPesos(double cantidadPesos) {
		this.cantidadPesos = cantidadPesos;
	}

	// definimos metodo get
	public double getTasaDolar() {
		return tasaDolar;
	}

	public double getTasaEuro() {
		return tasaEuro;
	}
	
	public double getCantidadPesos() {
		return cantidadPesos;
	}


	
	// Método para convertir pesos a dólares
	public double convertirDolares(double cantidadPesos) {
		return this.cantidadPesos / this.tasaDolar;
	}

	// metdo para convertir pesos a euros
	public double convertirEuros(double cantidadPesos) {
		return this.cantidadPesos / tasaEuro;
	}

}
