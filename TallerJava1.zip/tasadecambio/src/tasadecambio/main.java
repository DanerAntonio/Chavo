package tasadecambio;

import java.util.Scanner;

public class main  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);
		 
		    // Definir las tasas de cambio
	        double tasaDolar = 3948; // valor de 1 dolar en pesos
	        double tasaEuro = 4289; // valor de 1 euro en pesos
	       
	        
	        // Pedir al usuario que ingrese el valor en pesos
	        System.out.println("Ingrese el valor en pesos: ");
	        double cantidadPesos = scanner.nextDouble();
	        
	        // Crear un objeto de la clase Conversor
	        conversor conversor = new conversor(tasaDolar, tasaEuro, cantidadPesos);

	        // Convertir la cantidad de pesos ingresada a dólares y euros
	        double cantidadDolares = conversor.convertirDolares(tasaDolar);
	        double cantidadEuros = conversor.convertirEuros(tasaEuro);
	        
	        
	        // Imprimir los resultados de la conversión
	        System.out.println(cantidadPesos + " pesos equivale a " + cantidadDolares + " dólares.");
	        System.out.println(cantidadPesos + " pesos equivale a " + cantidadEuros + " euros.");
	        
	        scanner.close();
	    }
	}


